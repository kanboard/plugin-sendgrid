<?php

return array(
    'Help on Sendgrid integration' => 'Ajuda na integração do Sendgrid',
);

