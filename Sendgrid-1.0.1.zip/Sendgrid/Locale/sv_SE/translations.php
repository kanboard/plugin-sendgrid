<?php

return array(
    'Help on Sendgrid integration' => 'Hjälp för Sendgrid integration',
);

