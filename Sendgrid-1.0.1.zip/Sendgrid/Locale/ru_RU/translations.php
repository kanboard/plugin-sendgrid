<?php

return array(
    'Help on Sendgrid integration' => 'Справка о Sendgrid интеграции',
);

