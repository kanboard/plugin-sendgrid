<?php

return array(
    'Help on Sendgrid integration' => 'Ayuda sobre la integración con Sendgrid',
);

