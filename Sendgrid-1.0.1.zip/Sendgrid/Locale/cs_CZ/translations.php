<?php

return array(
    'Help on Sendgrid integration' => 'Hilfe bei Sendgrid-Integration',
);

