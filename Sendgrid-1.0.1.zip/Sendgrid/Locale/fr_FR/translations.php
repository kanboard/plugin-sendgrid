<?php

return array(
    'Help on Sendgrid integration' => 'Aide sur l\'intégration avec Sendgrid',
);

